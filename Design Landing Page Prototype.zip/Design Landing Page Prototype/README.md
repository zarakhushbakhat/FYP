
  # Design Landing Page Prototype

  This is a code bundle for Design Landing Page Prototype. The original project is available at https://www.figma.com/design/9DarRiTtKOhSDEkkVB2aqs/Design-Landing-Page-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  